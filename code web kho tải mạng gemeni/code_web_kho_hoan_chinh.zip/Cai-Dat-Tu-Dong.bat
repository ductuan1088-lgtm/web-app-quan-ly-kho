@echo off
chcp 65001 >nul
echo ========================================================
echo   CÀI ĐẶT MÔI TRƯỜNG & DEPENDENCIES CHO MÁY MỚI
echo ========================================================
echo.
echo 1. Dang kiem tra Node.js...
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [LOI] May tinh chua cai dat Node.js! Vui long tai va cai Node.js tai https://nodejs.org
    pause
    exit /b
)
echo [OK] Da tim thay Node.js.
echo.

echo 2. Dang cai dat thu vien cho Backend SQLite (server)...
cd /d "%~dp0server"
call npm install
echo.

echo 3. Dang cai dat thu vien cho Frontend Web (V2)...
cd /d "%~dp0V2"
call npm install
echo.

echo 4. Mo cong tuong lua Windows Firewall (Port 3000 va 5000)...
netsh advfirewall firewall add rule name="Mo cong Web Kho 3000" dir=in action=allow protocol=TCP localport=3000 >nul 2>&1
netsh advfirewall firewall add rule name="Mo cong Backend Kho 5000" dir=in action=allow protocol=TCP localport=5000 >nul 2>&1
echo [OK] Da mo cong tuong lua cho mang LAN.
echo.

echo ========================================================
echo   HOÀN TẤT CÀI ĐẶT! BẠN CÓ THỂ BẤM CHẠY-NGẦM ĐỂ DÙNG.
echo ========================================================
pause

@echo off
chcp 65001 >nul
echo ========================================================
echo       ĐANG DỪNG TOÀN BỘ HỆ THỐNG QUẢN LÝ KHO...
echo ========================================================
echo.
taskkill /F /IM node.exe >nul 2>&1
echo [OK] Đã tắt sạch các tiến trình Backend (Port 5000) và Frontend (Port 3000).
echo.
pause
